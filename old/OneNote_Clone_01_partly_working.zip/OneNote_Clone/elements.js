import { Editor } from 'https://cdn.skypack.dev/@tiptap/core?min'
import StarterKit from 'https://cdn.skypack.dev/@tiptap/starter-kit?min';

export class TextElement {
    constructor(data) {
        this.type = 'text';
        this.id = data.id || null;
        this.x = data.x || 100;
        this.y = data.y || 100;
        this.width = data.width || 300;
        this.height = data.height || 150;
        this.rotation = data.rotation || 0;
        this.content = data.content || '<p>Type here...</p>';
    }

    render(container) {
        this.element = document.createElement('div');
        this.element.className = 'element text-element';
        this.element.setAttribute('data-id', this.id);
        this.element.style.left = `${this.x}px`;
        this.element.style.top = `${this.y}px`;
        this.element.style.width = `${this.width}px`;
        this.element.style.height = `${this.height}px`;
        this.element.style.transform = `rotate(${this.rotation}deg)`;
        
        // Create editor container
        const editorContainer = document.createElement('div');
        editorContainer.className = 'editor-container';
        this.element.appendChild(editorContainer);
        
        // Initialize Tiptap editor
        this.editor = new Editor({
            element: editorContainer,
            extensions: [StarterKit],
            content: this.content,
            autofocus: false,
            editable: true,
            onUpdate: ({ editor }) => {
                this.content = editor.getHTML();
            }
        });
        
        container.appendChild(this.element);
    }

    attachEventListeners(app) {
        // Make element draggable
        let isDragging = false;
        let startX, startY, initialX, initialY;
        
        this.element.addEventListener('mousedown', (e) => {
            if (e.target.closest('.ProseMirror')) return;
            
            isDragging = true;
            startX = e.clientX;
            startY = e.clientY;
            initialX = this.x;
            initialY = this.y;
            
            e.preventDefault();
        });
        
        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            
            this.x = initialX + dx;
            this.y = initialY + dy;
            
            this.element.style.left = `${this.x}px`;
            this.element.style.top = `${this.y}px`;
            
            app.canvas.updateSelectionBox();
        });
        
        document.addEventListener('mouseup', () => {
            if (isDragging) {
                isDragging = false;
                app.updateElement(this.id, { x: this.x, y: this.y });
            }
        });
        
        // Handle selection
        this.element.addEventListener('click', (e) => {
            if (!e.target.closest('.ProseMirror')) {
                app.selectElement(this.id);
            }
        });
        
        // Handle context menu
        this.element.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            app.selectElement(this.id);
            app.ui.showContextMenu(e.clientX, e.clientY);
        });
    }
}

export class ImageElement {
    constructor(data) {
        this.type = 'image';
        this.id = data.id || null;
        this.x = data.x || 100;
        this.y = data.y || 100;
        this.width = data.width || 300;
        this.height = data.height || 200;
        this.rotation = data.rotation || 0;
        this.src = data.src || '';
        this.opacity = data.opacity || 1;
        this.borderWidth = data.borderWidth || 0;
        this.borderColor = data.borderColor || '#000000';
    }

    render(container) {
        this.element = document.createElement('div');
        this.element.className = 'element image-element';
        this.element.setAttribute('data-id', this.id);
        this.element.style.left = `${this.x}px`;
        this.element.style.top = `${this.y}px`;
        this.element.style.width = `${this.width}px`;
        this.element.style.height = `${this.height}px`;
        this.element.style.transform = `rotate(${this.rotation}deg)`;
        this.element.style.opacity = this.opacity;
        
        if (this.borderWidth > 0) {
            this.element.style.border = `${this.borderWidth}px solid ${this.borderColor}`;
        }
        
        const img = document.createElement('img');
        img.src = this.src;
        img.style.width = '100%';
        img.style.height = '100%';
        img.style.objectFit = 'contain';
        img.style.borderRadius = '4px';
        
        this.element.appendChild(img);
        container.appendChild(this.element);
    }

    attachEventListeners(app) {
        // Make element draggable
        let isDragging = false;
        let startX, startY, initialX, initialY;
        
        this.element.addEventListener('mousedown', (e) => {
            isDragging = true;
            startX = e.clientX;
            startY = e.clientY;
            initialX = this.x;
            initialY = this.y;
            
            e.preventDefault();
        });
        
        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            
            this.x = initialX + dx;
            this.y = initialY + dy;
            
            this.element.style.left = `${this.x}px`;
            this.element.style.top = `${this.y}px`;
            
            app.canvas.updateSelectionBox();
        });
        
        document.addEventListener('mouseup', () => {
            if (isDragging) {
                isDragging = false;
                app.updateElement(this.id, { x: this.x, y: this.y });
            }
        });
        
        // Handle selection
        this.element.addEventListener('click', () => {
            app.selectElement(this.id);
        });
        
        // Handle context menu
        this.element.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            app.selectElement(this.id);
            app.ui.showContextMenu(e.clientX, e.clientY);
        });
    }
}

export class ShapeElement {
    constructor(data) {
        this.type = 'shape';
        this.id = data.id || null;
        this.shape = data.shape || 'rectangle';
        this.x = data.x || 100;
        this.y = data.y || 100;
        this.width = data.width || 200;
        this.height = data.height || 150;
        this.rotation = data.rotation || 0;
        this.fillColor = data.fillColor || '#ffffff';
        this.strokeColor = data.strokeColor || '#000000';
        this.strokeWidth = data.strokeWidth || 2;
    }

    render(container) {
        this.element = document.createElement('div');
        this.element.className = 'element shape-element';
        this.element.setAttribute('data-id', this.id);
        this.element.style.left = `${this.x}px`;
        this.element.style.top = `${this.y}px`;
        this.element.style.width = `${this.width}px`;
        this.element.style.height = `${this.height}px`;
        this.element.style.transform = `rotate(${this.rotation}deg)`;
        this.element.style.backgroundColor = this.fillColor;
        this.element.style.border = `${this.strokeWidth}px solid ${this.strokeColor}`;
        
        if (this.shape === 'circle') {
            this.element.style.borderRadius = '50%';
        } else if (this.shape === 'triangle') {
            this.element.style.backgroundColor = 'transparent';
            this.element.style.border = 'none';
            
            // Create triangle using CSS
            this.element.style.width = '0';
            this.element.style.height = '0';
            this.element.style.borderLeft = `${this.width/2}px solid transparent`;
            this.element.style.borderRight = `${this.width/2}px solid transparent`;
            this.element.style.borderBottom = `${this.height}px solid ${this.fillColor}`;
        }
        
        container.appendChild(this.element);
    }

    attachEventListeners(app) {
        // Make element draggable
        let isDragging = false;
        let startX, startY, initialX, initialY;
        
        this.element.addEventListener('mousedown', (e) => {
            isDragging = true;
            startX = e.clientX;
            startY = e.clientY;
            initialX = this.x;
            initialY = this.y;
            
            e.preventDefault();
        });
        
        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            
            this.x = initialX + dx;
            this.y = initialY + dy;
            
            this.element.style.left = `${this.x}px`;
            this.element.style.top = `${this.y}px`;
            
            app.canvas.updateSelectionBox();
        });
        
        document.addEventListener('mouseup', () => {
            if (isDragging) {
                isDragging = false;
                app.updateElement(this.id, { x: this.x, y: this.y });
            }
        });
        
        // Handle selection
        this.element.addEventListener('click', () => {
            app.selectElement(this.id);
        });
        
        // Handle context menu
        this.element.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            app.selectElement(this.id);
            app.ui.showContextMenu(e.clientX, e.clientY);
        });
    }
}

export class MathElement {
    constructor(data) {
        this.type = 'math';
        this.id = data.id || null;
        this.x = data.x || 100;
        this.y = data.y || 100;
        this.width = data.width || 200;
        this.height = data.height || 100;
        this.rotation = data.rotation || 0;
        this.latex = data.latex || '';
        this.html = data.html || '';
    }

    render(container) {
        this.element = document.createElement('div');
        this.element.className = 'element math-element';
        this.element.setAttribute('data-id', this.id);
        this.element.style.left = `${this.x}px`;
        this.element.style.top = `${this.y}px`;
        this.element.style.width = `${this.width}px`;
        this.element.style.height = `${this.height}px`;
        this.element.style.transform = `rotate(${this.rotation}deg)`;
        
        // Render math using KaTeX
        if (this.html) {
            this.element.innerHTML = this.html;
        } else if (this.latex) {
            try {
                katex.render(this.latex, this.element, {
                    throwOnError: false,
                    displayMode: true
                });
            } catch (e) {
                this.element.textContent = 'Error rendering equation';
            }
        }
        
        container.appendChild(this.element);
    }

    attachEventListeners(app) {
        // Make element draggable
        let isDragging = false;
        let startX, startY, initialX, initialY;
        
        this.element.addEventListener('mousedown', (e) => {
            isDragging = true;
            startX = e.clientX;
            startY = e.clientY;
            initialX = this.x;
            initialY = this.y;
            
            e.preventDefault();
        });
        
        document.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            
            const dx = e.clientX - startX;
            const dy = e.clientY - startY;
            
            this.x = initialX + dx;
            this.y = initialY + dy;
            
            this.element.style.left = `${this.x}px`;
            this.element.style.top = `${this.y}px`;
            
            app.canvas.updateSelectionBox();
        });
        
        document.addEventListener('mouseup', () => {
            if (isDragging) {
                isDragging = false;
                app.updateElement(this.id, { x: this.x, y: this.y });
            }
        });
        
        // Handle selection
        this.element.addEventListener('click', () => {
            app.selectElement(this.id);
        });
        
        // Handle context menu
        this.element.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            app.selectElement(this.id);
            app.ui.showContextMenu(e.clientX, e.clientY);
        });
    }
}